
[![Actions Status](https://github.com/OCamlPro/ocaml-solidity/workflows/Main%20Workflow/badge.svg)](https://github.com/OCamlPro/ocaml-solidity/actions)
[![Release](https://img.shields.io/github/release/OCamlPro/ocaml-solidity.svg)](https://github.com/OCamlPro/ocaml-solidity/releases)

# ocaml-solidity


Ocaml-solidity provides a Solidity parser and typechecker


* Website: https://github.com/OcamlPro/ocaml-solidity
* General Documentation: https://OCamlPro.github.io/ocaml-solidity/sphinx
* API Documentation: https://OCamlPro.github.io/ocaml-solidity/doc
* Sources: https://github.com/OcamlPro/ocaml-solidity
