open Solidity_common

class virtual ['self] map = object (_ : 'self)
  method visit_ident : 'env -> Ident.t -> Ident.t =
    fun _ x -> x

  method visit_longident_contents : 'env -> relative LongIdent.t -> relative LongIdent.t =
    fun _ x -> x
end

class virtual ['self] endo = ['self] map

class virtual ['self] iter = object (_ : 'self)
  method visit_ident : 'env -> Ident.t -> unit =
    fun _ _ -> ()

  method visit_longident_contents : 'env -> relative LongIdent.t -> unit =
    fun _ _ -> ()
end
                                    
class virtual ['self] reduce = object (self : 'self)
  inherit [_] VisitorsRuntime.reduce
  method visit_ident : 'env -> Ident.t -> 's =
    fun _ _ -> self#zero

  method visit_longident_contents : 'env -> relative LongIdent.t -> 's =
    fun _ _ -> self#zero
end

class virtual ['self] mapreduce = object (self : 'self)
  inherit [_] VisitorsRuntime.mapreduce

  method visit_ident : 'env -> Ident.t -> Ident.t * 's =
    fun _ x -> (x, self#zero)

  method visit_longident_contents : 'env -> relative LongIdent.t -> relative LongIdent.t * 's =
    fun _ x -> (x, self#zero)
end

(*
class virtual ['self] fold = object (self : 'self)
  inherit [_] VisitorsRuntime.fold

  method virtual build_ident : _
  method virtual build_longident_contents : _

  method visit_ident = self#build_ident
  method visit_longident_contents = self#build_longident_contents
end
*)
