About
=====


Ocaml-solidity provides a Solidity parser and typechecker


Authors
-------

* David Declerck <david.declerck@ocamlpro.com>
* Steven De Oliveira <steven.de-oliveira@ocamlpro.com>
