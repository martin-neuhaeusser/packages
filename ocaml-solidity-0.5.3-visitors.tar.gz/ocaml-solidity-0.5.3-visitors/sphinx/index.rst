.. ocaml-solidity documentation master file, created by
   drom new
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ocaml-solidity
================

.. toctree::
   :maxdepth: 2
   :caption: Documentation

   Home <https://github.com/OcamlPro/ocaml-solidity>
   about
   install
   API doc <https://OCamlPro.github.io/ocaml-solidity/doc>
   license

   Devel and Issues on Github <https://github.com/OCamlPro/ocaml-solidity>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
