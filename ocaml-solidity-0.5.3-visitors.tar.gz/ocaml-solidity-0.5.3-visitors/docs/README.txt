To build the documentation:
~~~~~~~~~~~~~~~~~~~~~~~~~~~

* Run `make doc` or `drom doc`
* Then, check the documentation in _drom/docs/

xdg-open file:///$(pwd)/_drom/docs/index.html

